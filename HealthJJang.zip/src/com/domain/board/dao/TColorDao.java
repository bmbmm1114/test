package com.domain.board.dao;

import java.util.List;

import com.mydomain.vo.TColor;


public interface TColorDao {
 public List<TColor> selectTcolor();
}
